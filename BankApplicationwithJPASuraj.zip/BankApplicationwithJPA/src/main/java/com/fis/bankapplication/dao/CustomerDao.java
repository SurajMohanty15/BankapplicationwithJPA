package com.fis.bankapplication.dao;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerDao extends JpaRepository<Customer,Integer>{
//	public abstract String updateUser(int customerId,String name, String address) throws CustomerNotFound;
//	public abstract Customer getUser(int customerId) throws CustomerNotFound;
}
