package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountDao accountDAO;
	
	@Override
	public  String addAccount(Account account) {
		accountDAO.save(account);
		return "Account save to Database";
	}

	@Override
	public Optional<Account> getAccountByAccountId(int accountId){
		Optional<Account> accnt = accountDAO.findById(accountId);
			return accnt;
	}

	@Override
	public String updateAccount(int accountId,double amount) {
			accountDAO.updateAccount(accountId,amount);
			return "Account has been updated";
	}

	@Override
	public void deleteAccount(int accountId) {
		accountDAO.deleteById(accountId);
	}

	@Override
	public List<Account> getAllAccountsByBalanceRange(double minBal, double maxBal) {
		return accountDAO.getAllAccountsByBalanceRange(minBal,maxBal);
	}
	
	public List<Account> getAllAccounts(){
		return accountDAO.findAll();
	}

}
