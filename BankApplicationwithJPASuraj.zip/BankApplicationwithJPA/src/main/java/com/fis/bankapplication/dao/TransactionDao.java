package com.fis.bankapplication.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.bankapplication.exceptions.NotEnoughBalance;
import com.fis.bankapplication.model.Transaction;

public interface TransactionDao extends JpaRepository<Transaction,Long>{
	
	@Query("update Account set balance = balance+?2 where accountId=?1")
	@Modifying
	public abstract void deposit(int accountId,double amount);
	
	@Query("update Account set balance = balance-?2 where accountId=?1")
	@Modifying
	public abstract void withdraw(int accountId,double amount) throws NotEnoughBalance;
//	public abstract List<Transaction> getAllTranscationByAccountId(int accountId);
}
