package com.fis.bankapplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.TransactionDao;
import com.fis.bankapplication.exceptions.NotEnoughBalance;
import com.fis.bankapplication.model.Transaction;



@Service
@Transactional
public class TransactionServiceImpl implements TransactionService{
	
	@Autowired
	private TransactionDao transactionDAO;

	@Override
	public void deposit(int accountId, double amount) {
		transactionDAO.deposit(accountId, amount);
		Transaction transaction = new Transaction();
		transaction.setTransactionId(transaction.getTransactionId());
		transaction.setTranscationDate(transaction.getTranscationDate());
		transaction.setModeOfTransaction("Deposit");
		transaction.setFromAccount(accountId);
		transaction.setToAccount(accountId);
		transaction.setAmount(amount);
		transactionDAO.save(transaction);
	}

	@Override
	public void withdraw(int accountId, double amount) throws NotEnoughBalance {
		transactionDAO.withdraw(accountId, amount);
		Transaction transaction = new Transaction();
		transaction.setTransactionId(transaction.getTransactionId());
		transaction.setTranscationDate(transaction.getTranscationDate());
		transaction.setModeOfTransaction("Withdraw");
		transaction.setFromAccount(accountId);
		transaction.setToAccount(accountId);
		transaction.setAmount(amount);
		transactionDAO.save(transaction);
	}

	@Override
	public void fundTransfer(int fromAccountId, int toAccountId, double amount) throws NotEnoughBalance {
		transactionDAO.deposit(toAccountId, amount);
		transactionDAO.withdraw(fromAccountId, amount);
		Transaction transaction = new Transaction();
		transaction.setTransactionId(transaction.getTransactionId());
		transaction.setTranscationDate(transaction.getTranscationDate());
		transaction.setModeOfTransaction("Fund Transfer");
		transaction.setFromAccount(fromAccountId);
		transaction.setToAccount(toAccountId);
		transaction.setAmount(amount);
		transactionDAO.save(transaction);
	}

	@Override
	public List<Transaction> getAllTranscation() {
		return transactionDAO.findAll();
	}

//	@Override
//	public List<Transaction> getAllTranscationByAccountId(int accountId) {
//		return transactionDAO.getAllTranscationByAccountId(accountId);
//	}
}
